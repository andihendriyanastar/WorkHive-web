"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Star, Users, Shield, Headphones, Zap } from "lucide-react";

export default function PricingPage() {
  const plans = [
    {
      name: "Basic",
      price: "$9",
      period: "per user per month",
      description: "Perfect for small teams getting started",
      features: [
        "Up to 10 employees",
        "Basic attendance tracking",
        "Simple leave management",
        "Email support",
        "Mobile app access",
        "Basic reporting"
      ],
      popular: false,
      cta: "Get Started"
    },
    {
      name: "Pro",
      price: "$19",
      period: "per user per month",
      description: "Ideal for growing businesses",
      features: [
        "Up to 100 employees",
        "Advanced attendance with GPS",
        "Comprehensive leave management",
        "Priority email & chat support",
        "Advanced analytics & reporting",
        "Payroll integration",
        "API access",
        "Custom workflows"
      ],
      popular: true,
      cta: "Start Free Trial"
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "pricing",
      description: "For large organizations with custom needs",
      features: [
        "Unlimited employees",
        "Advanced attendance with AI verification",
        "Complete HR management suite",
        "24/7 dedicated support",
        "Advanced analytics & BI",
        "Full payroll integration",
        "API & webhook access",
        "Custom workflows & automation",
        "Dedicated account manager",
        "On-premise deployment option",
        "Custom integrations"
      ],
      popular: false,
      cta: "Contact Sales"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">WH</span>
            </div>
            <span className="font-bold text-xl text-primary">WorkHive</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
            <a href="/features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
            <a href="#pricing" className="text-primary font-medium">Pricing</a>
            <a href="/about" className="text-muted-foreground hover:text-primary transition-colors">About</a>
            <a href="/contact" className="text-muted-foreground hover:text-primary transition-colors">Contact</a>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline">Sign In</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4 bg-accent text-accent-foreground">
            Transparent Pricing
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Choose the perfect plan for your team. All plans include our core features with scalable options as you grow.
          </p>
          <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
            <CheckCircle className="h-4 w-4 text-accent" />
            <span>14-day free trial on all plans</span>
            <CheckCircle className="h-4 w-4 text-accent ml-4" />
            <span>No credit card required</span>
            <CheckCircle className="h-4 w-4 text-accent ml-4" />
            <span>Cancel anytime</span>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <Card key={index} className={`relative ${plan.popular ? 'border-2 border-accent shadow-lg' : 'border-primary/20'}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-accent text-accent-foreground px-4 py-2">
                      <Star className="h-4 w-4 mr-1" />
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-8">
                  <CardTitle className="text-2xl font-bold text-primary">{plan.name}</CardTitle>
                  <CardDescription className="text-base">{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-primary">{plan.price}</span>
                    <span className="text-muted-foreground ml-2">{plan.period}</span>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <Button 
                    className={`w-full ${plan.popular ? 'bg-accent text-accent-foreground hover:bg-accent/90' : 'bg-primary text-primary-foreground hover:bg-primary/90'}`}
                    size="lg"
                  >
                    {plan.cta}
                  </Button>
                  
                  <div className="space-y-4">
                    {plan.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-start space-x-3">
                        <CheckCircle className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Compare Features
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Detailed comparison of features across all plans
            </p>
          </div>
          
          <div className="max-w-6xl mx-auto">
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="grid grid-cols-4 gap-0">
                {/* Header */}
                <div className="p-6 border-r border-b bg-muted/50">
                  <h3 className="font-semibold">Features</h3>
                </div>
                <div className="p-6 border-r border-b text-center">
                  <h4 className="font-semibold text-primary">Basic</h4>
                </div>
                <div className="p-6 border-r border-b text-center bg-accent/5">
                  <h4 className="font-semibold text-primary">Pro</h4>
                </div>
                <div className="p-6 border-b text-center">
                  <h4 className="font-semibold text-primary">Enterprise</h4>
                </div>
                
                {/* Feature Rows */}
                {[
                  { feature: "Employee Limit", basic: "10", pro: "100", enterprise: "Unlimited" },
                  { feature: "Attendance Tracking", basic: "Basic", pro: "Advanced", enterprise: "AI-Powered" },
                  { feature: "GPS Location", basic: "✗", pro: "✓", enterprise: "✓" },
                  { feature: "Camera Verification", basic: "✗", pro: "✓", enterprise: "✓" },
                  { feature: "Leave Management", basic: "Basic", pro: "Advanced", enterprise: "Complete" },
                  { feature: "Payroll Integration", basic: "✗", pro: "✓", enterprise: "✓" },
                  { feature: "Analytics & Reports", basic: "Basic", pro: "Advanced", enterprise: "BI Tools" },
                  { feature: "API Access", basic: "✗", pro: "✓", enterprise: "✓" },
                  { feature: "Support", basic: "Email", pro: "Priority", enterprise: "24/7 Dedicated" },
                  { feature: "Custom Workflows", basic: "✗", pro: "✓", enterprise: "✓" },
                  { feature: "Mobile App", basic: "✓", pro: "✓", enterprise: "✓" },
                  { feature: "Custom Integrations", basic: "✗", pro: "✗", enterprise: "✓" }
                ].map((row, index) => (
                  <div key={index} className="contents">
                    <div className="p-4 border-r border-b">
                      <span className="text-sm font-medium">{row.feature}</span>
                    </div>
                    <div className="p-4 border-r border-b text-center">
                      <span className="text-sm">{row.basic}</span>
                    </div>
                    <div className="p-4 border-r border-b text-center bg-accent/5">
                      <span className="text-sm font-medium text-primary">{row.pro}</span>
                    </div>
                    <div className="p-4 border-b text-center">
                      <span className="text-sm font-medium text-primary">{row.enterprise}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to know about our pricing and plans
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-primary">Can I change plans anytime?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Yes, you can upgrade or downgrade your plan at any time. Changes take effect at the start of your next billing cycle.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-primary">What payment methods do you accept?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  We accept all major credit cards, debit cards, and bank transfers. For Enterprise plans, we also offer invoice-based billing.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-primary">Is there a long-term contract?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  No, all our plans are month-to-month. You can cancel anytime without penalty. We also offer annual plans with discounted pricing.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-primary">Do you offer discounts for non-profits?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Yes, we offer special pricing for registered non-profit organizations and educational institutions. Contact our sales team for details.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary to-accent">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of companies already using WorkHive to streamline their HR processes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-3">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3 border-white text-white hover:bg-white hover:text-primary">
              Contact Sales
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}