"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Carousel } from "@/components/ui/carousel";
import { CheckCircle, Users, Smartphone, Shield, Clock, MapPin, Camera, FileText, Calculator } from "lucide-react";

export default function Home() {
  // Real WorkHive screenshots for the carousel
  const workHiveScreenshots = [
    {
      src: "https://z-cdn-media.chatglm.cn/files/70991e3e-5fff-4c7c-9185-d3524cf8ac27_pasted_image_1758177800755.png?auth_key=1789715272-b00956978d864d2a947c617de7dbcb5e-0-f631b3e53207a668d1a6c2285e7fbbba",
      alt: "WorkHive Super Admin Dashboard",
      title: "Super Admin Dashboard",
      description: "Comprehensive overview of your entire workforce with real-time analytics and insights."
    },
    {
      src: "https://z-cdn-media.chatglm.cn/files/40e5f984-69c7-48e7-b1da-6e2c3577df2a_attandance.png?auth_key=1789715272-3c33d7ec92394a72b212e07fe31dba29-0-d5dd4a6e7ba596568042a292ea61dbc9",
      alt: "WorkHive Attendance Management",
      title: "Attendance Management",
      description: "Track employee attendance with location and camera verification in real-time."
    },
    {
      src: "https://z-cdn-media.chatglm.cn/files/d49ac898-a0ff-48ff-be97-1770ee082f2f_employee%20record.png?auth_key=1789715272-f4789456292046a28db4b6f0895e0e79-0-c77bd5e768954f43c375477b395ce95a",
      alt: "WorkHive Employee Records",
      title: "Employee Records",
      description: "Manage employee profiles, roles, and organizational structure efficiently."
    },
    {
      src: "https://z-cdn-media.chatglm.cn/files/10ede24e-eff3-4fbd-906e-7fe27a8437eb_payroll.png?auth_key=1789715272-ffc0814fcd5a4000927c170d42fe628e-0-06c62a224e44910cb9b4bf18c1db7d4d",
      alt: "WorkHive Payroll Dashboard",
      title: "Payroll Dashboard",
      description: "Seamless payroll integration with automated calculations and digital payslips."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-10 w-10 flex items-center justify-center">
              <img 
                src="https://z-cdn-media.chatglm.cn/files/fc2cda5a-1127-4931-aaee-e3bca53d40b7_logo.png?auth_key=1789714807-e357dcc739fd4a8cb73c14e152d7f61e-0-07814120dd7dd8a9d93f74a5fa9869b2" 
                alt="WorkHive Logo" 
                className="h-10 w-10 object-contain"
              />
            </div>
            <span className="font-bold text-xl text-accent">WorkHive</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <a href="#features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
            <a href="#pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a>
            <a href="#about" className="text-muted-foreground hover:text-primary transition-colors">About</a>
            <a href="#contact" className="text-muted-foreground hover:text-primary transition-colors">Contact</a>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline">Sign In</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4 bg-accent text-accent-foreground">
            Integrated Attendance & HR Solutions
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-accent mb-6">
            WorkHive
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-4 font-medium">
            Simplicity in Workforce Management
          </p>
          <p className="text-lg text-muted-foreground mb-8 max-w-3xl mx-auto">
            Streamline attendance, leave, and payroll management with smart, reliable technology.
          </p>
          
          {/* Interactive Carousel with Real Screenshots */}
          <div className="relative mx-auto max-w-6xl mb-12">
            <Carousel 
              images={workHiveScreenshots}
              autoPlay={true}
              autoPlayInterval={6000}
            />
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-8 py-3">
              Try for Free
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3 border-primary text-primary hover:bg-primary hover:text-primary-foreground">
              Request a Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Key Advantages Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Why Choose WorkHive?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Experience the perfect blend of simplicity and power in workforce management
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center border-primary/20 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-primary">Simple UI/UX</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Our interface is designed for everyone, making workforce management intuitive and accessible for all users.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-primary/20 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-primary">3 User Roles</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Flexible role-based access with Super Admin, Manager, and Staff roles for optimal workflow management.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-primary/20 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-primary">PWA Ready</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Install directly on phones without the Play Store. Works offline and delivers a native app experience.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-primary/20 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-primary">Modern Security</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Advanced backend security protocols protect your sensitive workforce data with enterprise-grade encryption.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Preview Section */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Powerful Features
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to manage your workforce efficiently
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                <MapPin className="h-6 w-6 text-accent-foreground" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">Smart Attendance</h3>
                <p className="text-muted-foreground">
                  Location and camera-based check-in/out with real-time attendance reports and analytics.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                <Users className="h-6 w-6 text-accent-foreground" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">Employee Management</h3>
                <p className="text-muted-foreground">
                  Comprehensive profile management, organizational structure, and role-based authorization.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                <FileText className="h-6 w-6 text-accent-foreground" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">Leave Management</h3>
                <p className="text-muted-foreground">
                  Streamlined online leave request and approval process with automated balance tracking.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                <Calculator className="h-6 w-6 text-accent-foreground" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">Payroll Integration</h3>
                <p className="text-muted-foreground">
                  Seamless integration with attendance data for accurate salary calculation and digital payslips.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary to-accent">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Transform Your Workforce Management?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of companies already using WorkHive to streamline their HR processes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-3">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3 border-white text-white hover:bg-white hover:text-primary">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="h-10 w-10 flex items-center justify-center">
                  <img 
                    src="https://z-cdn-media.chatglm.cn/files/fc2cda5a-1127-4931-aaee-e3bca53d40b7_logo.png?auth_key=1789714807-e357dcc739fd4a8cb73c14e152d7f61e-0-07814120dd7dd8a9d93f74a5fa9869b2" 
                    alt="WorkHive Logo" 
                    className="h-10 w-10 object-contain"
                  />
                </div>
                <span className="font-bold text-xl text-accent">WorkHive</span>
              </div>
              <p className="text-primary-foreground/80">
                Simplicity in Workforce Management
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-primary-foreground/80">
                <li><a href="#features" className="hover:text-accent transition-colors">Features</a></li>
                <li><a href="#pricing" className="hover:text-accent transition-colors">Pricing</a></li>
                <li><a href="#about" className="hover:text-accent transition-colors">About</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-primary-foreground/80">
                <li><a href="#contact" className="hover:text-accent transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Support</a></li>
                <li><a href="#" className="hover:text-accent transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <p className="text-primary-foreground/80 mb-4">
                Get in touch with our team
              </p>
              <Button variant="secondary" className="bg-accent text-primary hover:bg-accent/90">
                Contact Us
              </Button>
            </div>
          </div>
          <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center text-primary-foreground/60">
            <p>&copy; 2024 WorkHive. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}