"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Camera, 
  Users, 
  FileText, 
  Calculator, 
  Clock, 
  CheckCircle, 
  BarChart3, 
  Shield,
  Smartphone,
  Bell,
  Calendar,
  TrendingUp
} from "lucide-react";

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">WH</span>
            </div>
            <span className="font-bold text-xl text-primary">WorkHive</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
            <a href="#features" className="text-primary font-medium">Features</a>
            <a href="/pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a>
            <a href="/about" className="text-muted-foreground hover:text-primary transition-colors">About</a>
            <a href="/contact" className="text-muted-foreground hover:text-primary transition-colors">Contact</a>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline">Sign In</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4 bg-accent text-accent-foreground">
            Comprehensive Features
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            Powerful Workforce Management Features
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Discover how WorkHive streamlines every aspect of your HR and attendance management with our comprehensive feature set.
          </p>
        </div>
      </section>

      {/* Attendance Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <MapPin className="h-6 w-6 text-primary-foreground" />
                </div>
                <h2 className="text-3xl font-bold text-primary">Smart Attendance System</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                Revolutionize how you track employee attendance with our advanced location and camera-based verification system.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Location-Based Check-in</h4>
                    <p className="text-muted-foreground">GPS and geofencing technology ensures employees check in from designated work locations.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Camera Verification</h4>
                    <p className="text-muted-foreground">AI-powered facial recognition and photo capture prevents buddy punching and ensures authenticity.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Real-time Analytics</h4>
                    <p className="text-muted-foreground">Live dashboards and comprehensive reports provide instant insights into attendance patterns.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Automated Alerts</h4>
                    <p className="text-muted-foreground">Instant notifications for late arrivals, early departures, and attendance anomalies.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-primary to-accent rounded-2xl p-8 shadow-2xl">
                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center">
                        <Camera className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Today's Attendance</h3>
                        <p className="text-sm text-muted-foreground">Live Status</p>
                      </div>
                    </div>
                    <Badge className="bg-accent text-accent-foreground">Live</Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-muted rounded-lg p-4 text-center">
                      <p className="text-2xl font-bold text-primary">142</p>
                      <p className="text-sm text-muted-foreground">Present</p>
                    </div>
                    <div className="bg-muted rounded-lg p-4 text-center">
                      <p className="text-2xl font-bold text-accent">8</p>
                      <p className="text-sm text-muted-foreground">On Leave</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Attendance Rate</span>
                      <span className="text-sm font-semibold text-primary">94.7%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: '94.7%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Employee Management Section */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="bg-gradient-to-br from-accent to-primary rounded-2xl p-8 shadow-2xl">
                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="h-10 w-10 bg-accent rounded-full flex items-center justify-center">
                      <Users className="h-5 w-5 text-accent-foreground" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Employee Directory</h3>
                      <p className="text-sm text-muted-foreground">150 Total Employees</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="h-8 w-8 bg-primary rounded-full flex items-center justify-center">
                          <span className="text-xs text-primary-foreground font-bold">JD</span>
                        </div>
                        <div>
                          <p className="font-medium text-sm">John Doe</p>
                          <p className="text-xs text-muted-foreground">Software Engineer</p>
                        </div>
                      </div>
                      <Badge variant="secondary">Active</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="h-8 w-8 bg-primary rounded-full flex items-center justify-center">
                          <span className="text-xs text-primary-foreground font-bold">AS</span>
                        </div>
                        <div>
                          <p className="font-medium text-sm">Alice Smith</p>
                          <p className="text-xs text-muted-foreground">HR Manager</p>
                        </div>
                      </div>
                      <Badge variant="secondary">Active</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="h-8 w-8 bg-primary rounded-full flex items-center justify-center">
                          <span className="text-xs text-primary-foreground font-bold">BJ</span>
                        </div>
                        <div>
                          <p className="font-medium text-sm">Bob Johnson</p>
                          <p className="text-xs text-muted-foreground">Sales Director</p>
                        </div>
                      </div>
                      <Badge variant="outline">On Leave</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="order-1 lg:order-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-accent-foreground" />
                </div>
                <h2 className="text-3xl font-bold text-primary">Employee Management</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                Comprehensive employee profile management with organizational structure and role-based access control.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Profile Management</h4>
                    <p className="text-muted-foreground">Complete employee profiles with personal details, documents, and employment history.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Organizational Structure</h4>
                    <p className="text-muted-foreground">Hierarchical organization chart with department and team management.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Role-Based Authorization</h4>
                    <p className="text-muted-foreground">Granular access control with Super Admin, Manager, and Staff roles.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Document Management</h4>
                    <p className="text-muted-foreground">Secure storage for employee documents, contracts, and certifications.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leave Management Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-primary-foreground" />
                </div>
                <h2 className="text-3xl font-bold text-primary">Leave Management</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                Streamlined leave request and approval process with automated balance tracking and comprehensive reporting.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Online Leave Requests</h4>
                    <p className="text-muted-foreground">Easy-to-use interface for employees to submit leave requests with detailed information.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Automated Approvals</h4>
                    <p className="text-muted-foreground">Multi-level approval workflow with automatic routing based on organizational hierarchy.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Leave Balance Tracking</h4>
                    <p className="text-muted-foreground">Real-time tracking of various leave types with automatic accrual and carry-over calculations.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Leave Calendar</h4>
                    <p className="text-muted-foreground">Team-wide calendar view for better planning and resource allocation.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-primary to-accent rounded-2xl p-8 shadow-2xl">
                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Leave Balance</h3>
                        <p className="text-sm text-muted-foreground">John Doe</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-muted rounded-lg p-4 text-center">
                      <p className="text-xl font-bold text-primary">12</p>
                      <p className="text-sm text-muted-foreground">Annual Leave</p>
                    </div>
                    <div className="bg-muted rounded-lg p-4 text-center">
                      <p className="text-xl font-bold text-accent">5</p>
                      <p className="text-sm text-muted-foreground">Sick Leave</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Pending Requests</span>
                      <span className="font-medium text-primary">1</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Approved This Month</span>
                      <span className="font-medium text-accent">2</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payroll Section */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="bg-gradient-to-br from-accent to-primary rounded-2xl p-8 shadow-2xl">
                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="h-10 w-10 bg-accent rounded-full flex items-center justify-center">
                      <Calculator className="h-5 w-5 text-accent-foreground" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Payroll Summary</h3>
                      <p className="text-sm text-muted-foreground">November 2024</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Basic Salary</span>
                      <span className="font-medium">$45,000</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Overtime</span>
                      <span className="font-medium text-accent">+$2,500</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Deductions</span>
                      <span className="font-medium">-$3,200</span>
                    </div>
                    <div className="border-t pt-2">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">Net Pay</span>
                        <span className="font-bold text-primary text-lg">$44,300</span>
                      </div>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                    Download Payslip
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="order-1 lg:order-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                  <Calculator className="h-6 w-6 text-accent-foreground" />
                </div>
                <h2 className="text-3xl font-bold text-primary">Payroll Integration</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                Seamless integration with attendance data for accurate salary calculation, bonuses, and digital payslips.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Automated Calculations</h4>
                    <p className="text-muted-foreground">Automatic salary calculations based on attendance, overtime, and leave data.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Digital Payslips</h4>
                    <p className="text-muted-foreground">Secure, downloadable payslips with detailed breakdown of earnings and deductions.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Tax Compliance</h4>
                    <p className="text-muted-foreground">Automated tax calculations and compliance with local labor laws and regulations.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-primary">Bonus & Allowances</h4>
                    <p className="text-muted-foreground">Flexible management of bonuses, allowances, and other compensation components.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary to-accent">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Experience These Features?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Start your free trial today and discover how WorkHive can transform your workforce management.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-3">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3 border-white text-white hover:bg-white hover:text-primary">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}