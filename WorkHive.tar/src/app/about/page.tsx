"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Target, 
  Lightbulb, 
  Award, 
  Heart, 
  Briefcase,
  CheckCircle,
  Star,
  Globe
} from "lucide-react";

export default function AboutPage() {
  const teamMembers = [
    {
      name: "Sarah Johnson",
      role: "CEO & Founder",
      bio: "HR technology expert with 15+ years of experience in workforce management solutions.",
      image: "SJ"
    },
    {
      name: "Michael Chen",
      role: "CTO",
      bio: "Full-stack developer specializing in scalable enterprise applications and cloud architecture.",
      image: "MC"
    },
    {
      name: "Emily Rodriguez",
      role: "Head of Product",
      bio: "Product strategist passionate about creating intuitive user experiences for HR professionals.",
      image: "ER"
    },
    {
      name: "David Kim",
      role: "Lead Engineer",
      bio: "Software engineer with expertise in mobile development and system integration.",
      image: "DK"
    }
  ];

  const values = [
    {
      icon: <Heart className="h-6 w-6" />,
      title: "User-Centric",
      description: "We put our users at the center of everything we do, creating solutions that truly matter."
    },
    {
      icon: <Target className="h-6 w-6" />,
      title: "Innovation",
      description: "We constantly push boundaries to bring cutting-edge technology to workforce management."
    },
    {
      icon: <CheckCircle className="h-6 w-6" />,
      title: "Reliability",
      description: "We build robust, dependable systems that businesses can count on every day."
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "Inclusivity",
      description: "We create solutions that work for businesses of all sizes and types."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">WH</span>
            </div>
            <span className="font-bold text-xl text-primary">WorkHive</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
            <a href="/features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
            <a href="/pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a>
            <a href="#about" className="text-primary font-medium">About</a>
            <a href="/contact" className="text-muted-foreground hover:text-primary transition-colors">Contact</a>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline">Sign In</Button>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto text-center">
          <Badge variant="secondary" className="mb-4 bg-accent text-accent-foreground">
            Our Story
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            About WorkHive
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            We're on a mission to simplify workforce management through innovative technology and human-centered design.
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <Target className="h-6 w-6 text-primary-foreground" />
                </div>
                <h2 className="text-3xl font-bold text-primary">Our Mission</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                To empower businesses of all sizes with simple, powerful, and affordable workforce management solutions that drive productivity and employee satisfaction.
              </p>
              <p className="text-muted-foreground">
                We believe that managing people shouldn't be complicated. Our mission is to remove the complexity from HR processes, allowing businesses to focus on what truly matters - their people and their growth.
              </p>
            </div>
            
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                  <Lightbulb className="h-6 w-6 text-accent-foreground" />
                </div>
                <h2 className="text-3xl font-bold text-primary">Our Vision</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                To become the global leader in workforce management technology, setting new standards for innovation, usability, and customer success.
              </p>
              <p className="text-muted-foreground">
                We envision a future where every business, regardless of size or location, has access to enterprise-grade HR tools that are intuitive, affordable, and transformative.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
                The WorkHive Story
              </h2>
              <p className="text-lg text-muted-foreground">
                How we started and why we exist
              </p>
            </div>
            
            <div className="space-y-8">
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                      <Lightbulb className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-primary">The Problem</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    WorkHive was born from a simple observation: too many businesses struggle with outdated, complex, and expensive workforce management systems. Small and medium-sized businesses were particularly underserved, forced to choose between cumbersome spreadsheets and enterprise software that was beyond their budget and needs.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                      <Star className="h-5 w-5 text-accent-foreground" />
                    </div>
                    <CardTitle className="text-primary">The Solution</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    In 2020, our founder Sarah Johnson, a former HR executive, experienced these pain points firsthand. She assembled a team of passionate technologists and HR experts to create WorkHive - a platform that would combine the power of enterprise software with the simplicity and affordability that growing businesses need.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                      <Award className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-primary">The Journey</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Since our launch, WorkHive has grown from a simple attendance tracking app to a comprehensive workforce management platform. Today, we serve thousands of businesses across multiple countries, helping them manage their most valuable asset - their people - with unprecedented ease and efficiency.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Our Core Values
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="text-center border-primary/20 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="text-primary-foreground">
                      {value.icon}
                    </div>
                  </div>
                  <CardTitle className="text-primary">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {value.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Meet Our Team
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The passionate people behind WorkHive
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map((member, index) => (
              <Card key={index} className="text-center border-primary/20 hover:shadow-lg transition-shadow">
                <CardHeader className="pb-4">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-white">{member.image}</span>
                  </div>
                  <CardTitle className="text-primary">{member.name}</CardTitle>
                  <CardDescription className="text-accent font-medium">
                    {member.role}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {member.bio}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-lg text-muted-foreground mb-6">
              We're always looking for talented people to join our team
            </p>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              View Open Positions
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">5000+</div>
              <p className="text-muted-foreground">Businesses Trust Us</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">50K+</div>
              <p className="text-muted-foreground">Active Users</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">99.9%</div>
              <p className="text-muted-foreground">Uptime</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">24/7</div>
              <p className="text-muted-foreground">Support</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary to-accent">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Join Our Journey
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Be part of the workforce management revolution. Let's build the future of HR together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-3">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3 border-white text-white hover:bg-white hover:text-primary">
              Contact Us
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}